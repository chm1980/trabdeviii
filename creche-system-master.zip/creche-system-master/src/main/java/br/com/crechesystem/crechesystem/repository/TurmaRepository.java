package br.com.crechesystem.crechesystem.repository;

import br.com.crechesystem.crechesystem.domain.Turma;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurmaRepository extends JpaRepository<Turma, Long> {
}