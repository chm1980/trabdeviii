package br.com.crechesystem.crechesystem.security.enums;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER
}