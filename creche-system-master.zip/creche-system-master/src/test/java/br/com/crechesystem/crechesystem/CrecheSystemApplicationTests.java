package br.com.crechesystem.crechesystem;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CrecheSystemApplicationTests {

	@Test
	public void contextLoads() {
	}

}
